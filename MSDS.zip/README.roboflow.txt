
MSDS - v2 2021-12-07 6:57pm
==============================

This dataset was exported via roboflow.ai on December 7, 2021 at 11:57 PM GMT

It includes 2993 images.
Ships are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


